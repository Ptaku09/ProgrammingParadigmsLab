public abstract class Primitive extends Item {
    public Primitive(MyPoint position) {
        super(position);
    }
}
