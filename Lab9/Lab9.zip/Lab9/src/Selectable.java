public interface Selectable {
    void draw();

    void addItem(Item item);
}
